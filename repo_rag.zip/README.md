# repo_rag

Ask **Claude** questions about a code repository **and** its documents.

- **Docling** parses real documents in the repo — PDF, DOCX, PPTX, XLSX — using
  layout/table/OCR models (far better than naive text extraction). Code and
  plain-text files are read directly.
- **Hybrid retrieval** finds the relevant chunks:
  - **BM25** — keyword search; precise for identifiers/exact names.
  - **Embeddings** (`fastembed`, ONNX, ~130 MB, no torch/Ollama) — semantic
    search; bridges vocabulary gaps ("login" → `authenticate()`).
  - Merged with **Reciprocal Rank Fusion**.
- A **chat model** writes the final answer from the retrieved chunks, citing
  its sources. The model is pluggable (see *Model providers* below): Claude,
  OpenAI, or any self-hosted OpenAI-compatible server.

The core (parsing, retrieval, embeddings) is model-agnostic — the only thing a
provider has to do is *chat*. The embedding model only turns text into vectors;
it never generates answers.

## Setup

```bash
uv sync
```

Provide your key(s) either as environment variables **or** in a `.env` file
(auto-loaded, git-ignored):

```bash
cp .env.example .env      # then edit .env
# or, per-session in PowerShell:
$env:ANTHROPIC_API_KEY = "sk-ant-..."
```

Only fill in the keys for the provider you use (see *Model providers*). The
embedding/retrieval side needs no key at all.

## Usage

```bash
# 1. Build an index from a repo path (parses docs + code, builds hybrid index)
uv run main.py index C:\path\to\some\repo

# 2. Ask a question
uv run main.py ask "how does authentication work?"

# 3. Or an interactive loop
uv run main.py chat
```

Options:

- `index --no-embeddings` — BM25-only (skip the embedding model entirely).
- `ask -k 12` — retrieve more chunks (default 8).
- `--index-path PATH` — where the index is stored (default `.repo_rag/index.pkl`).

## Model providers

The `ask` / `chat` commands take `--provider`. Retrieval is identical across
all of them — only the answer-writer changes.

```bash
# Claude (default) — needs ANTHROPIC_API_KEY
uv run main.py ask "..."

# OpenAI cloud — needs OPENAI_API_KEY
uv run main.py ask "..." --provider openai --model gpt-4o-mini

# Self-hosted / local model via any OpenAI-compatible server
#   Ollama:    base-url http://localhost:11434/v1   (api key ignored)
#   vLLM / LM Studio / LocalAI / llama.cpp: point at their /v1 endpoint
uv run main.py ask "..." --provider local \
    --base-url http://localhost:11434/v1 --model llama3.1
```

Env-var equivalents for the OpenAI-compatible path: `OPENAI_API_KEY`,
`OPENAI_BASE_URL`, `OPENAI_MODEL`.

Only a **chat** model is ever needed — embeddings stay local and key-free.

## How it fits together

```
repo path ──▶ Docling (docs) + direct read (code) ──▶ chunks
                                                          │
                          ┌── BM25 keyword ranking ──┐    │
            question ─────┤                          ├─ RRF fuse ─▶ top-k chunks
                          └── embedding similarity ──┘                  │
                                                                        ▼
                                                          Claude (Anthropic API)
                                                                        │
                                                                   cited answer
```

## Roadmap

- **GraphRAG via graphify** — layer a knowledge graph over the repo so
  architecture/relationship questions ("how do these modules connect?") pull in
  graph neighbors and community summaries alongside chunk retrieval.
