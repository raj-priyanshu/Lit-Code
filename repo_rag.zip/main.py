import sys

from repo_rag.cli import main

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
