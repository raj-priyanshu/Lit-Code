```banner
```

# Octopie Notes

> Octo-Pie only adds to **Inbox**. Drag or use Shift+↑↓ to move items to Saved.

## Bookmarks

<!-- OCTO:BOOKMARK:START -->
### Saved
<!-- OCTO:BM:SAVED:S -->
_No bookmarks._
<!-- OCTO:BM:SAVED:E -->
### Inbox
<!-- OCTO:BM:INBOX:S -->
_No bookmarks._
<!-- OCTO:BM:INBOX:E -->
<!-- OCTO:BOOKMARK:END -->

## TODO

<!-- OCTO:TODO:START -->
### Saved
<!-- OCTO:TD:SAVED:S -->
_No todos._
<!-- OCTO:TD:SAVED:E -->
### Inbox
<!-- OCTO:TD:INBOX:S -->
_No todos._
<!-- OCTO:TD:INBOX:E -->
<!-- OCTO:TODO:END -->
