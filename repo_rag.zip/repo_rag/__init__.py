"""repo_rag — index a code repository and ask questions about it with Claude.

Retrieval is BM25 (pure-Python keyword search, no local model). Document files
(PDF/DOCX/PPTX/XLSX/HTML/Markdown) are parsed with Docling; code/text files are
read directly. Claude writes the final answer from the retrieved chunks.
"""

__all__ = ["ingest", "index", "rag"]
