"""Command-line interface: build an index from a repo, then ask questions.

    uv run main.py index <repo_path>
    uv run main.py ask "how does authentication work?"
    uv run main.py chat
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .index import RepoIndex
from .ingest import build_chunks
from .llm import make_provider
from .rag import answer, print_sources

DEFAULT_INDEX = Path(".repo_rag") / "index.pkl"


def _cmd_index(args: argparse.Namespace) -> int:
    repo = Path(args.repo_path)
    if not repo.is_dir():
        print(f"error: not a directory: {repo}", file=sys.stderr)
        return 2
    chunks = build_chunks(repo)
    if not chunks:
        print("error: nothing indexable found.", file=sys.stderr)
        return 1
    idx = RepoIndex.build(chunks, str(repo.resolve()),
                          use_embeddings=not args.no_embeddings)
    out = Path(args.index_path)
    idx.save(out)
    print(f"Saved index -> {out}  ({len(chunks)} chunks, {idx.mode})")
    return 0


def _cmd_pipeline(args: argparse.Namespace) -> int:
    from .pipeline import run_pipeline

    repos = list(args.repo_paths) + list(args.repo)
    if not repos:
        print("error: give at least one repo (positional path or --repo DIR).",
              file=sys.stderr)
        return 2
    idx = run_pipeline(
        repos,
        references=args.references,
        out_dir=args.out,
        use_embeddings=not args.no_embeddings,
        use_graph=not args.no_graph,
    )
    return 0 if idx is not None else 1


def _load_index(index_path: str) -> RepoIndex:
    path = Path(index_path)
    if not path.exists():
        print(f"error: no index at {path}. Run `index <repo_path>` first.",
              file=sys.stderr)
        raise SystemExit(2)
    return RepoIndex.load(path)


def _cmd_ask(args: argparse.Namespace) -> int:
    provider = make_provider(args.provider, args.model, args.base_url)
    idx = _load_index(args.index_path)
    print(f"[{provider.name}:{provider.model}]")
    _, hits = answer(idx, args.question, provider, k=args.k)
    print_sources(hits)
    return 0


def _cmd_chat(args: argparse.Namespace) -> int:
    provider = make_provider(args.provider, args.model, args.base_url)
    idx = _load_index(args.index_path)
    print(f"Repo chat [{provider.name}:{provider.model}]. "
          "Each question is answered independently. Ctrl-C to quit.\n")
    try:
        while True:
            q = input("you> ").strip()
            if not q:
                continue
            if q in {"exit", "quit", ":q"}:
                break
            print()
            _, hits = answer(idx, q, provider, k=args.k)
            print_sources(hits)
            print()
    except (EOFError, KeyboardInterrupt):
        print()
    return 0


def _add_model_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--provider", choices=["anthropic", "openai", "local"],
                   default="anthropic",
                   help="chat model backend (default: anthropic)")
    p.add_argument("--model", default=None,
                   help="model name (default depends on provider)")
    p.add_argument("--base-url", default=None,
                   help="OpenAI-compatible endpoint, e.g. http://localhost:11434/v1 "
                        "for a self-hosted model (provider openai/local)")
    p.add_argument("--index-path", default=str(DEFAULT_INDEX))
    p.add_argument("-k", type=int, default=8, help="chunks to retrieve")


def _load_dotenv() -> None:
    """Load a .env file (searched from CWD upward) so keys can live there."""
    try:
        from dotenv import find_dotenv, load_dotenv
    except ImportError:
        return
    load_dotenv(find_dotenv(usecwd=True))


def main(argv: list[str] | None = None) -> int:
    _load_dotenv()
    parser = argparse.ArgumentParser(
        prog="repo-rag",
        description="Index a code repository and ask Claude about it (BM25 + Docling).",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_index = sub.add_parser("index", help="build a search index from a repo path")
    p_index.add_argument("repo_path", help="path to the repository to index")
    p_index.add_argument("--index-path", default=str(DEFAULT_INDEX),
                         help=f"where to save the index (default: {DEFAULT_INDEX})")
    p_index.add_argument("--no-embeddings", action="store_true",
                         help="skip semantic embeddings; BM25 keyword search only")
    p_index.set_defaults(func=_cmd_index)

    p_pipe = sub.add_parser(
        "pipeline",
        help="one-shot: index code + documents (Docling) AND build the graphify graph",
    )
    p_pipe.add_argument("repo_paths", nargs="*",
                        help="repository path(s) to index (positional; repeatable)")
    p_pipe.add_argument("--repo", action="append", default=[], metavar="DIR",
                        help="repository path (repeatable; alternative to positional)")
    p_pipe.add_argument("--references", "--refrences", action="append", default=None,
                        dest="references", metavar="DIR",
                        help="document folder (PDF/Excel/DOCX/...) to index via Docling (repeatable)")
    p_pipe.add_argument("--out", default=".repo_rag",
                        help="output directory for index + graph (default: .repo_rag)")
    p_pipe.add_argument("--no-embeddings", action="store_true",
                        help="skip semantic embeddings; BM25 keyword search only")
    p_pipe.add_argument("--no-graph", action="store_true",
                        help="skip the graphify knowledge graph")
    p_pipe.set_defaults(func=_cmd_pipeline)

    p_ask = sub.add_parser("ask", help="ask a single question")
    p_ask.add_argument("question")
    _add_model_args(p_ask)
    p_ask.set_defaults(func=_cmd_ask)

    p_chat = sub.add_parser("chat", help="interactive question loop")
    _add_model_args(p_chat)
    p_chat.set_defaults(func=_cmd_chat)

    args = parser.parse_args(argv)
    return args.func(args)
