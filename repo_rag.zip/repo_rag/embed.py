"""Semantic embeddings via fastembed (ONNX, CPU, no torch, no Ollama).

The model (~130 MB, ``BAAI/bge-small-en-v1.5``, 384-dim) downloads once on
first use and is cached by fastembed. Vectors are L2-normalised so a dot
product equals cosine similarity.
"""

from __future__ import annotations

import os
from pathlib import Path

import numpy as np

MODEL_NAME = "BAAI/bge-small-en-v1.5"
DIM = 384

# Persist the model outside the system temp dir so it isn't re-downloaded.
# On Windows the HF cache defaults to symlinks, which fail without admin/dev
# mode (WinError 1314) and trigger a slow download-retry loop on every run.
# Forcing copies (HF_HUB_DISABLE_SYMLINKS) makes the cache work cleanly so the
# model is loaded from disk after the first download.
CACHE_DIR = Path.home() / ".cache" / "repo_rag" / "fastembed"
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS", "1")
os.environ.setdefault("HF_HUB_DISABLE_SYMLINKS_WARNING", "1")

_model = None


def available() -> bool:
    try:
        import fastembed  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def _get_model():
    global _model
    if _model is None:
        from fastembed import TextEmbedding

        cached = (CACHE_DIR / f"models--qdrant--{MODEL_NAME.split('/')[-1]}-onnx-q").exists()
        note = "loading from cache" if cached else "first run downloads ~130 MB"
        print(f"Embedding model {MODEL_NAME} ({note}) ...")
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        _model = TextEmbedding(model_name=MODEL_NAME, cache_dir=str(CACHE_DIR))
    return _model


def _normalize(arr: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(arr, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return (arr / norms).astype(np.float32)


def embed_passages(texts: list[str], batch: int = 256) -> np.ndarray:
    """Embed document/code chunks. Returns (N, DIM) float32, L2-normalised."""
    model = _get_model()
    vecs = np.array(list(model.embed(texts, batch_size=batch)), dtype=np.float32)
    return _normalize(vecs)


def embed_query(text: str) -> np.ndarray:
    """Embed a query. Returns (DIM,) float32, L2-normalised."""
    model = _get_model()
    # bge models prepend a query instruction via query_embed when available.
    embedder = getattr(model, "query_embed", model.embed)
    vec = np.array(list(embedder([text])), dtype=np.float32)
    return _normalize(vec)[0]
