"""Knowledge-graph layer built with graphify's deterministic AST extraction.

This uses graphify's *structural* extraction (imports, calls, definitions) which
needs no LLM — so the whole pipeline stays automated. It produces the same
artifacts the graphify skill does (graph.json + graph.html), which the GraphRAG
retrieval layer can later read.

Document-only files (PDF/Excel/…) have no AST and don't appear in the graph;
they live in the chunk index instead. The graph is the *code structure* lens.
"""

from __future__ import annotations

from pathlib import Path


def available() -> bool:
    try:
        import graphify  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def build_code_graph(roots: list[Path], out_dir: Path) -> dict | None:
    """AST-extract code under `roots`, cluster, and write graph.json + graph.html.

    Returns {nodes, edges, communities} or None if graphify is unavailable or
    no code was found.
    """
    if not available():
        print("  ! graphify not installed; skipping graph (add 'graphifyy').")
        return None

    from graphify.build import build_from_json
    from graphify.cluster import cluster
    from graphify.export import to_html, to_json
    from graphify.extract import collect_files, extract

    files: list[Path] = []
    for root in roots:
        if not root.exists():
            continue
        files.extend(collect_files(root) if root.is_dir() else [root])
    # de-dup while preserving order
    seen: set[str] = set()
    files = [f for f in files if not (str(f) in seen or seen.add(str(f)))]
    if not files:
        print("  ! no code files found for the graph.")
        return None

    print(f"Graph: AST-extracting {len(files)} code files ...")
    result = extract(files)
    graph = build_from_json(result)
    if graph.number_of_nodes() == 0:
        print("  ! graph extraction produced no nodes.")
        return None

    communities = cluster(graph)
    out_dir.mkdir(parents=True, exist_ok=True)
    to_json(graph, communities, str(out_dir / "graph.json"))
    if graph.number_of_nodes() <= 5000:
        to_html(graph, communities, str(out_dir / "graph.html"))
        viz = out_dir / "graph.html"
    else:
        print(f"  (graph has {graph.number_of_nodes()} nodes — skipping HTML viz >5000)")
        viz = None

    stats = {
        "nodes": graph.number_of_nodes(),
        "edges": graph.number_of_edges(),
        "communities": len(communities),
    }
    print(f"Graph -> {out_dir / 'graph.json'}"
          f"  ({stats['nodes']} nodes, {stats['edges']} edges, "
          f"{stats['communities']} communities)")
    if viz:
        print(f"Graph viz -> {viz}")
    return stats
