"""Hybrid index over repository chunks: BM25 keywords + semantic embeddings.

Two retrievers run per query:
  * BM25 — weighted keyword match; precise for identifiers/exact names.
  * Embeddings — semantic similarity; bridges vocabulary gaps ("login" ->
    ``authenticate()``).
Their rankings are merged with Reciprocal Rank Fusion (RRF), which combines
*positions* rather than raw scores, so the two very different score scales
never need normalising.

The code-aware tokenizer also splits ``getUserToken`` / ``get_user_token`` into
parts so a query for "user token" matches both.
"""

from __future__ import annotations

import pickle
import re
from collections import defaultdict
from dataclasses import asdict
from pathlib import Path

import numpy as np
from rank_bm25 import BM25Okapi

from . import embed
from .ingest import Chunk

_WORD_RE = re.compile(r"[A-Za-z0-9_]+")
_CAMEL_RE = re.compile(r"[A-Z]+(?=[A-Z][a-z])|[A-Z]?[a-z0-9]+|[A-Z]+|[0-9]+")

INDEX_VERSION = 2
RRF_K = 60          # RRF damping constant (standard default)
FUSE_DEPTH = 50     # how many top hits from each retriever to fuse


def _split_identifier(token: str) -> list[str]:
    parts: list[str] = []
    for piece in token.split("_"):
        parts.extend(_CAMEL_RE.findall(piece))
    return parts


def tokenize(text: str) -> list[str]:
    """Lowercase word tokens, plus sub-tokens from identifier splitting."""
    tokens: list[str] = []
    for raw in _WORD_RE.findall(text):
        low = raw.lower()
        tokens.append(low)
        for sub in _split_identifier(raw):
            subl = sub.lower()
            if subl != low:
                tokens.append(subl)
    return tokens


class RepoIndex:
    """A built hybrid index plus the chunks it ranks."""

    def __init__(
        self,
        chunks: list[Chunk],
        repo_root: str,
        embeddings: np.ndarray | None = None,
        bm25_weight: float = 1.0,
        sem_weight: float = 1.0,
    ):
        self.chunks = chunks
        self.repo_root = repo_root
        self.embeddings = embeddings  # (N, DIM) float32, L2-normalised, or None
        self.bm25_weight = bm25_weight
        self.sem_weight = sem_weight
        self._corpus_tokens = [tokenize(c.text) for c in chunks]
        self._bm25 = BM25Okapi(self._corpus_tokens) if chunks else None

    # ---- construction -------------------------------------------------------

    @classmethod
    def build(cls, chunks: list[Chunk], repo_root: str,
              use_embeddings: bool = True) -> "RepoIndex":
        embeddings = None
        if use_embeddings and chunks and embed.available():
            print(f"Embedding {len(chunks)} chunks for semantic search ...")
            embeddings = embed.embed_passages([c.text for c in chunks])
        elif use_embeddings and not embed.available():
            print("  ! fastembed not available; using BM25 only.")
        return cls(chunks, repo_root, embeddings=embeddings)

    # ---- retrieval ----------------------------------------------------------

    def _bm25_ranking(self, query: str, depth: int) -> list[int]:
        if not self._bm25:
            return []
        scores = self._bm25.get_scores(tokenize(query))
        order = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)
        return [i for i in order[:depth] if scores[i] > 0]

    def _semantic_ranking(self, query: str, depth: int) -> list[int]:
        if self.embeddings is None or not embed.available():
            return []
        qv = embed.embed_query(query)            # (DIM,)
        sims = self.embeddings @ qv              # cosine (vectors normalised)
        order = sorted(range(len(sims)), key=lambda i: sims[i], reverse=True)
        return list(order[:depth])

    def search(self, query: str, k: int = 8) -> list[tuple[Chunk, float]]:
        """Return up to `k` (chunk, fused_score) pairs, best first."""
        if not self.chunks:
            return []
        rankings = [
            (self._bm25_ranking(query, FUSE_DEPTH), self.bm25_weight),
            (self._semantic_ranking(query, FUSE_DEPTH), self.sem_weight),
        ]
        fused: dict[int, float] = defaultdict(float)
        for ranking, weight in rankings:
            for rank, idx in enumerate(ranking):
                fused[idx] += weight / (RRF_K + rank + 1)
        if not fused:
            return []
        top = sorted(fused.items(), key=lambda kv: kv[1], reverse=True)[:k]
        return [(self.chunks[i], score) for i, score in top]

    @property
    def mode(self) -> str:
        return "hybrid (BM25 + embeddings)" if self.embeddings is not None else "BM25 only"

    # ---- persistence --------------------------------------------------------

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": INDEX_VERSION,
            "repo_root": self.repo_root,
            "chunks": [asdict(c) for c in self.chunks],
            "embeddings": self.embeddings,
            "bm25_weight": self.bm25_weight,
            "sem_weight": self.sem_weight,
        }
        with path.open("wb") as fh:
            pickle.dump(payload, fh)

    @classmethod
    def load(cls, path: Path) -> "RepoIndex":
        with path.open("rb") as fh:
            payload = pickle.load(fh)
        if payload.get("version") != INDEX_VERSION:
            raise ValueError(
                f"Index at {path} was built by an incompatible version; "
                "re-run `index`."
            )
        chunks = [Chunk(**d) for d in payload["chunks"]]
        return cls(
            chunks,
            payload["repo_root"],
            embeddings=payload.get("embeddings"),
            bm25_weight=payload.get("bm25_weight", 1.0),
            sem_weight=payload.get("sem_weight", 1.0),
        )
