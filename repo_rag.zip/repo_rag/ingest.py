"""Walk a repository, turn its files into text, and split them into chunks.

- Document files (PDF, DOCX, PPTX, XLSX, HTML, Markdown, AsciiDoc, CSV) are
  converted to Markdown with Docling.
- Code and plain-text files are read directly.

Every chunk keeps its source path and line range so answers can cite them.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

# ---- file selection ---------------------------------------------------------

# Files handed to Docling for parsing/normalisation.
DOC_EXTS = {
    ".pdf", ".docx", ".pptx", ".xlsx", ".html", ".htm",
    ".md", ".markdown", ".adoc", ".asciidoc", ".csv",
}

# Files read directly as text. (No exhaustive list — see `_looks_textual`.)
CODE_EXTS = {
    ".py", ".pyi", ".js", ".mjs", ".cjs", ".jsx", ".ts", ".tsx",
    ".java", ".kt", ".kts", ".scala", ".go", ".rs", ".rb", ".php",
    ".c", ".h", ".cc", ".cpp", ".hpp", ".cxx", ".cs", ".swift", ".m",
    ".sh", ".bash", ".zsh", ".ps1", ".bat", ".sql", ".r", ".lua", ".pl",
    ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".properties",
    ".json", ".jsonc", ".xml", ".gradle", ".txt", ".rst", ".tex",
    ".vue", ".svelte", ".dockerfile", ".env", ".gitignore", ".makefile",
}

# Directories never worth indexing.
SKIP_DIRS = {
    ".git", ".hg", ".svn", "node_modules", ".venv", "venv", "env",
    "__pycache__", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    "dist", "build", "target", "out", ".next", ".nuxt", ".cache",
    ".idea", ".vscode", ".octo", ".repo_rag", "site-packages",
    ".tox", ".eggs", "coverage", ".gradle",
}

MAX_FILE_BYTES = 1_500_000  # skip anything bigger; usually generated/binary


@dataclass
class Chunk:
    """A retrievable span of text with enough metadata to cite it."""

    text: str
    path: str        # repo-relative, forward-slash path
    start_line: int  # 1-based, inclusive
    end_line: int    # 1-based, inclusive
    kind: str        # "code" | "doc"


def _looks_textual(path: Path) -> bool:
    ext = path.suffix.lower()
    if ext in CODE_EXTS or path.name.lower() in {"dockerfile", "makefile", "readme"}:
        return True
    return False


def _is_probably_binary(data: bytes) -> bool:
    if b"\x00" in data[:4096]:
        return True
    # Heuristic: too many non-text bytes in the head.
    head = data[:4096]
    if not head:
        return False
    textish = sum(1 for b in head if b == 9 or b == 10 or b == 13 or 32 <= b < 127)
    return textish / len(head) < 0.85


def iter_files(root: Path):
    """Yield indexable files under `root`, skipping junk dirs and huge files."""
    for path in root.rglob("*"):
        if path.is_dir():
            continue
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        try:
            if path.stat().st_size > MAX_FILE_BYTES:
                continue
        except OSError:
            continue
        ext = path.suffix.lower()
        if ext in DOC_EXTS or _looks_textual(path):
            yield path


def _read_text(path: Path) -> str | None:
    try:
        data = path.read_bytes()
    except OSError:
        return None
    if _is_probably_binary(data):
        return None
    return data.decode("utf-8", errors="replace")


# ---- Docling (lazy, optional) ----------------------------------------------

_converter = None


def _get_converter():
    """Import and build a Docling converter on first use.

    Imported lazily so that code/text indexing still works even if Docling
    isn't importable in the current environment.
    """
    global _converter
    if _converter is None:
        from docling.document_converter import DocumentConverter

        _converter = DocumentConverter()
    return _converter


def _convert_with_docling(path: Path) -> str | None:
    try:
        result = _get_converter().convert(str(path))
        return result.document.export_to_markdown()
    except Exception as exc:  # noqa: BLE001 — never let one file kill indexing
        print(f"  ! docling failed on {path.name}: {exc}", file=sys.stderr)
        return None


# ---- chunking ---------------------------------------------------------------

def chunk_text(text: str, path: str, kind: str,
               max_chars: int = 1500, overlap_lines: int = 15) -> list[Chunk]:
    """Split text into overlapping, line-aligned chunks.

    Line alignment keeps citations meaningful; the overlap avoids losing
    context that straddles a chunk boundary.
    """
    lines = text.splitlines()
    n = len(lines)
    chunks: list[Chunk] = []
    i = 0
    while i < n:
        start = i
        size = 0
        while i < n and size < max_chars:
            size += len(lines[i]) + 1
            i += 1
        end = i  # exclusive
        body = "\n".join(lines[start:end]).strip()
        if body:
            chunks.append(Chunk(body, path, start + 1, end, kind))
        if i >= n:
            break
        nxt = end - overlap_lines
        i = nxt if nxt > start else end  # guarantee forward progress
    return chunks


def build_chunks(root: Path) -> list[Chunk]:
    """Convert every indexable file under `root` into a flat list of chunks."""
    root = root.resolve()
    chunks: list[Chunk] = []
    files = list(iter_files(root))
    print(f"Scanning {len(files)} files under {root} ...")
    for path in files:
        rel = path.relative_to(root).as_posix()
        ext = path.suffix.lower()
        if ext in DOC_EXTS and ext not in {".md", ".markdown"}:
            text = _convert_with_docling(path)
            kind = "doc"
            if text is None:  # fall back to raw read for text-ish docs
                text = _read_text(path)
        elif ext in {".md", ".markdown"}:
            # Markdown is already text; Docling adds little. Read directly.
            text = _read_text(path)
            kind = "doc"
        else:
            text = _read_text(path)
            kind = "code"
        if not text or not text.strip():
            continue
        chunks.extend(chunk_text(text, rel, kind))
    print(f"Built {len(chunks)} chunks.")
    return chunks
