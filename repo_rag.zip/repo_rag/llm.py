"""Pluggable chat-model layer.

The core (ingest + retrieval) is model-agnostic. The only thing a model must do
here is *chat*: given a system prompt and a user prompt, stream back text. That
single capability is captured by `LLMProvider`.

Providers:
  * AnthropicProvider          — Claude via the Anthropic API.
  * OpenAICompatibleProvider   — OpenAI cloud *and* any OpenAI-compatible server
                                 (vLLM, Ollama, LM Studio, LocalAI, llama.cpp,
                                 TGI) — just change `base_url`.

Embeddings are handled separately in `embed.py` and never touch this layer.
"""

from __future__ import annotations

import os
import sys
from typing import Iterator, Protocol

DEFAULT_MODELS = {
    "anthropic": "claude-opus-4-8",
    "openai": "gpt-4o-mini",
}


class LLMProvider(Protocol):
    name: str
    model: str

    def stream(self, system: str, user: str, max_tokens: int = 4096) -> Iterator[str]:
        ...


class AnthropicProvider:
    """Claude via the Anthropic API (streaming, cached system prompt, adaptive thinking)."""

    def __init__(self, model: str = DEFAULT_MODELS["anthropic"]):
        if not (os.environ.get("ANTHROPIC_API_KEY")
                or os.environ.get("ANTHROPIC_AUTH_TOKEN")):
            raise SystemExit("error: set ANTHROPIC_API_KEY for the anthropic provider.")
        import anthropic

        self.client = anthropic.Anthropic()
        self.model = model
        self.name = "anthropic"

    def stream(self, system: str, user: str, max_tokens: int = 4096) -> Iterator[str]:
        system_blocks = [{
            "type": "text",
            "text": system,
            "cache_control": {"type": "ephemeral"},
        }]
        with self.client.messages.stream(
            model=self.model,
            max_tokens=max_tokens,
            system=system_blocks,
            thinking={"type": "adaptive"},
            messages=[{"role": "user", "content": user}],
        ) as s:
            yield from s.text_stream


class OpenAICompatibleProvider:
    """OpenAI cloud or any OpenAI-compatible endpoint (self-hosted included).

    `base_url=None` targets OpenAI cloud. Point it at e.g.
    ``http://localhost:11434/v1`` (Ollama) or your vLLM/LM Studio server to use a
    self-hosted model. Self-hosted servers usually ignore the API key, so a
    placeholder is fine when none is set.
    """

    def __init__(self, model: str, base_url: str | None = None,
                 api_key: str | None = None, name: str = "openai"):
        from openai import OpenAI

        api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if base_url is None and not api_key:
            raise SystemExit("error: set OPENAI_API_KEY for the openai provider.")
        # Fail fast on a stalled network instead of hanging for minutes.
        self.client = OpenAI(base_url=base_url, api_key=api_key or "not-needed",
                             timeout=60.0, max_retries=2)
        self.model = model
        self.name = name
        self.base_url = base_url

    def stream(self, system: str, user: str, max_tokens: int = 4096) -> Iterator[str]:
        resp = self.client.chat.completions.create(
            model=self.model,
            max_tokens=max_tokens,
            stream=True,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        )
        for chunk in resp:
            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta.content
            if delta:
                yield delta


def make_provider(provider: str, model: str | None = None,
                  base_url: str | None = None) -> LLMProvider:
    """Build a provider from CLI/env settings."""
    if provider == "anthropic":
        return AnthropicProvider(model or DEFAULT_MODELS["anthropic"])

    if provider == "openai":
        return OpenAICompatibleProvider(
            model or os.environ.get("OPENAI_MODEL") or DEFAULT_MODELS["openai"],
            base_url=base_url,  # None -> OpenAI cloud
            name="openai",
        )

    if provider == "local":
        url = base_url or os.environ.get("OPENAI_BASE_URL")
        if not url:
            raise SystemExit(
                "error: the local provider needs --base-url or OPENAI_BASE_URL "
                "(e.g. http://localhost:11434/v1 for Ollama)."
            )
        mdl = model or os.environ.get("OPENAI_MODEL")
        if not mdl:
            raise SystemExit("error: the local provider needs --model (the served model name).")
        return OpenAICompatibleProvider(mdl, base_url=url, name="local")

    print(f"error: unknown provider '{provider}'", file=sys.stderr)
    raise SystemExit(2)
