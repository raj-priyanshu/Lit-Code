"""One-shot pipeline: index code + documents AND build the knowledge graph.

Given a repo path (and optionally a folder of reference documents), this:
  1. Chunks the code and the documents — PDF/DOCX/PPTX/XLSX go through Docling.
  2. Builds the hybrid BM25 + embedding index  -> <out>/index.pkl
  3. Builds the graphify code graph            -> <out>/graphify-out/

So a single command leaves you with every reference for the project ready at
once: searchable chunks (code + docs) and a structural graph.
"""

from __future__ import annotations

from pathlib import Path

from . import graph as graphmod
from .index import RepoIndex
from .ingest import build_chunks


def run_pipeline(
    repos: list[str],
    references: list[str] | None = None,
    out_dir: str = ".repo_rag",
    use_embeddings: bool = True,
    use_graph: bool = True,
) -> RepoIndex | None:
    out = Path(out_dir)
    repo_paths = [Path(r) for r in repos]
    ref_paths = [Path(r) for r in (references or [])]

    sources: list[Path] = []
    for p in repo_paths + ref_paths:
        if p.exists():
            sources.append(p)
        else:
            print(f"  ! path not found, skipping: {p}")
    if not sources:
        print("error: none of the given paths exist.")
        return None

    # When indexing more than one source, prefix each chunk's path with its
    # source folder name so citations stay unambiguous across repos.
    multi = len(sources) > 1

    # 1 + 2: chunk every source (code read directly, docs via Docling), index.
    print("== Step 1/2: indexing code + documents ==")
    all_chunks = []
    for src in sources:
        chunks = build_chunks(src)
        if multi:
            prefix = src.name
            for c in chunks:
                c.path = f"{prefix}/{c.path}"
        all_chunks.extend(chunks)
    if not all_chunks:
        print("error: nothing indexable found in the given paths.")
        return None

    repo_root = ", ".join(str(p.resolve()) for p in repo_paths) or str(sources[0].resolve())
    idx = RepoIndex.build(all_chunks, repo_root, use_embeddings=use_embeddings)
    index_path = out / "index.pkl"
    idx.save(index_path)
    print(f"Index -> {index_path}  ({len(all_chunks)} chunks, {idx.mode})")

    # 3: structural code graph over the same sources.
    if use_graph:
        print("\n== Step 3: building knowledge graph (graphify) ==")
        graphmod.build_code_graph(sources, out / "graphify-out")

    print(f"\nDone. Everything for this project is under {out}/")
    return idx
