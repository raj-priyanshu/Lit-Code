"""Answer a question about the repo: retrieve chunks, then ask the LLM.

Retrieval and prompt-building are model-agnostic; the actual generation is
delegated to an `LLMProvider` (see `llm.py`), so Claude, OpenAI, or a
self-hosted model are interchangeable.
"""

from __future__ import annotations

from .index import RepoIndex
from .ingest import Chunk
from .llm import LLMProvider

SYSTEM_PROMPT = (
    "You are a senior engineer answering questions about a specific code "
    "repository. You are given numbered context snippets retrieved from that "
    "repository, each labelled with its file path and line range.\n\n"
    "Rules:\n"
    "- Answer using the provided context as your primary source of truth.\n"
    "- Cite the snippets you rely on inline using their numbers, e.g. [3].\n"
    "- Quote short, relevant code spans when it helps.\n"
    "- If the context is insufficient to answer confidently, say so plainly "
    "and point to where the answer would likely live (file/dir) rather than "
    "inventing details.\n"
    "- Be concise and concrete. Prefer specifics from the code over generic "
    "explanation."
)


def _format_context(hits: list[tuple[Chunk, float]]) -> str:
    blocks: list[str] = []
    for n, (chunk, _score) in enumerate(hits, start=1):
        header = f"[{n}] {chunk.path}:{chunk.start_line}-{chunk.end_line} ({chunk.kind})"
        blocks.append(f"{header}\n```\n{chunk.text}\n```")
    return "\n\n".join(blocks)


def answer(
    index: RepoIndex,
    question: str,
    provider: LLMProvider,
    k: int = 8,
) -> tuple[str, list[tuple[Chunk, float]]]:
    """Retrieve top-`k` chunks and stream the model's answer to stdout.

    Returns the full answer text and the chunks used (for source listing).
    """
    print("Searching index ...", flush=True)
    hits = index.search(question, k=k)
    if not hits:
        msg = (
            "No matching content found in the index for that question. "
            "Try different keywords, or re-index if the repo changed."
        )
        print(msg)
        return msg, []

    context = _format_context(hits)
    user_content = (
        "<repository_context>\n"
        f"{context}\n"
        "</repository_context>\n\n"
        f"Question: {question}"
    )

    print(f"Answer ({provider.name}:{provider.model}):\n", flush=True)
    parts: list[str] = []
    for delta in provider.stream(SYSTEM_PROMPT, user_content, max_tokens=4096):
        parts.append(delta)
        print(delta, end="", flush=True)
    print()
    return "".join(parts), hits


def print_sources(hits: list[tuple[Chunk, float]]) -> None:
    if not hits:
        return
    print("\nSources:")
    for n, (chunk, score) in enumerate(hits, start=1):
        print(f"  [{n}] {chunk.path}:{chunk.start_line}-{chunk.end_line}  "
              f"(score {score:.2f})")
